const express = require('express');
const router = express.Router();
const Task = require('../models/Task');
const mongoose = require('mongoose');
/*
 Fetch All Task List
*/
router.get('/', async (req, res) => {
    const tasks = await Task.find().sort({ _id: -1 });
    res.status(200).json({ status: true, data: tasks })
});

/*
 Create  Task 
*/
router.post('/create', async (req, res) => {
    const formData = req.body;
    const tasks = await Task.insertOne({
        name: formData?.name,
        type: formData?.type
    });
    res.status(201).json({ status: true, data: tasks })
});

/*
 Update  Task 
*/
router.put('/update/:id', async (req, res) => {
    const formData = req.body;
    const updateId = req.params.id
    const tasks = await Task.updateOne(
        {
            _id: updateId
        }, // Where Clause
        {
            $set: {
                name: formData?.name,
                type: formData?.type
            }
        }
    );
    res.status(202).json({ status: true, data: tasks })
});

/*
 Delete  Task 
*/
router.delete('/delete/:id', async (req, res) => {
    const id = req.params.id
    const tasks = await Task.deleteOne({
        _id: id
    })
    res.status(200).json({ status: true , data: tasks })
});

/*
 Insert Multiple Task 
*/

router.post('/createmany', async (req, res) => {
    const formData = req.body;
    const tasks = await Task.insertMany(formData );
    res.status(201).json({ status: true, data: tasks })
});

        /*update
        Update Multiple Task 
        */

        router.put('/updatemany', async (req, res) => {
            try {
                const tasks = req.body;
                                        
                if (!Array.isArray(tasks) || tasks.length === 0) {
                    return res.status(400).json({ status: false, message: 'Payload must be a non-empty array' });
                }

                const hasInvalidIds = tasks.some(task => !task._id || task._id.trim() === "");

                if (hasInvalidIds) {
                    return res.status(400).json({ status: false, message: 'Each task must have a valid _id' });
                }
        
                const bulkOps = tasks.map(task =>({
                    
                        updateOne: {
                            filter: { _id: task._id },
                            update: { $set: { name: task.name, type: task.type } }
                        }
                    
                })); 
        
                const result = await Task.bulkWrite(bulkOps);
        
                res.status(200).json({ status: true, data: result });
            } catch (error) {
                console.error(error);
                res.status(500).json({ status: false, message: 'Bulk update failed' });
            }
        });
        
        

/*
 Insert OR Update  Task 
*/
router.post('/upsert', async (req, res) => {
    try {
        const { name, type, id } = req.body;
        let filter = {};

        if (id) {
            if (!mongoose.Types.ObjectId.isValid(id)) {
                return res.status(400).json({ status: false, message: 'Invalid ID' });
            }
            filter = { _id: id };
        } else {
            // Use a unique field as fallback or allow insert with generated _id
            filter = { name }; // if 'name' is not unique, consider removing filter entirely
        }

        const update = { $set: { name, type } };
        const options = { upsert: true };

        const tasks = await Task.updateOne(filter, update, options);
        res.status(200).json({ status: true, data: tasks });
    } catch (error) {
        console.error(error);
        res.status(500).json({ status: false, message: 'Something went wrong' });
    }
});


module.exports = router; 